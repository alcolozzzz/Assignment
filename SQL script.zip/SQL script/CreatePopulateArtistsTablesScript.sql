﻿------------------------------------------------------------------------------
-- Created: BALIGADOO Shiv Krisen	Date: 21-03-2019
-- Modified: xxxx					Date: xxx
------------------------------------------------------------------------------
-- Aim: Create a database and two tables with the artists information.
------------------------------------------------------------------------------
-- Description: 
-- 1. Create a database ArtistDB if it does not exist.Use the database.
-- 2. If table tblArtist already exists, drop both tables.
-- 3. Create two tables in the database called tblArtist and tblArtistAliases. 
-- 4. Insert the values into the table tblArtist and tblArtistAliases
------------------------------------------------------------------------------

-- 1. Create database if it does not exist + use database.
------------------------------------------------------------------------------
IF DB_ID('ArtistDB') IS NULL
	CREATE DATABASE ArtistDB	
GO

USE ArtistDB
GO

-- 2. If table tblArtist or tblArtistAliases already exists, drop them.
------------------------------------------------------------------------------
IF OBJECT_ID(N'dbo.tblArtist', N'U') IS NOT NULL
	DROP TABLE tblArtistAliases
	DROP TABLE tblArtist
GO


-- 3. Create the tables in the database called tblArtist and tblArtistAliases
------------------------------------------------------------------------------
CREATE TABLE tblArtist
(
	[Guid] UNIQUEIDENTIFIER ,
	[Name] NVARCHAR(50) NOT NULL,
	Country CHAR(2) NOT NULL		-- Country is always known for an artist.
	CONSTRAINT tblArtist_pk PRIMARY KEY CLUSTERED ([Guid])
)
GO

CREATE TABLE tblArtistAliases
(
	idAlias INT IDENTITY(1,1),
	[Guid] UNIQUEIDENTIFIER,
	Alias NVARCHAR(200) NOT NULL,
	CONSTRAINT tblArtistAliases_pk PRIMARY KEY CLUSTERED (idAlias),
	CONSTRAINT tblArtistAliases_fk FOREIGN KEY ([Guid]) REFERENCES tblArtist([Guid]))
GO

-- 4. Populate the tables tblArtist and tblArtistAliases
------------------------------------------------------------------------------
BEGIN TRY
	
	BEGIN TRANSACTION -- To ensure completeness of all the data.

	-- Populate table with given values in excel sheet.
	-- Presence of Unicode characters in aliases -use N'

	INSERT INTO tblArtist 
		VALUES ('65f4f0c5-ef9e-490c-aee3-909e7ae6b2ab','Metallica','US')
		
		INSERT INTO tblArtistAliases
		VALUES('65f4f0c5-ef9e-490c-aee3-909e7ae6b2ab',N'Metalica')

		INSERT INTO tblArtistAliases
		VALUES('65f4f0c5-ef9e-490c-aee3-909e7ae6b2ab',N'메탈리카')

-------------------

	INSERT INTO tblArtist 
		VALUES ('650e7db6-b795-4eb5-a702-5ea2fc46c848','Lady Gaga','US')
	
		INSERT INTO tblArtistAliases
		VALUES('650e7db6-b795-4eb5-a702-5ea2fc46c848',N'Lady Ga Ga')

		INSERT INTO tblArtistAliases
		VALUES('650e7db6-b795-4eb5-a702-5ea2fc46c848',N'Stefani Joanne Angelina Germanotta')

-------------------
	INSERT INTO tblArtist 
	   VALUES ('c44e9c22-ef82-4a77-9bcd-af6c958446d6','Mumford & Sons','GB')

-------------------   	
	INSERT INTO tblArtist 
	   VALUES ('435f1441-0f43-479d-92db-a506449a686b','Mott the Hoople','GB')

		INSERT INTO tblArtistAliases
			VALUES('435f1441-0f43-479d-92db-a506449a686b',N'Mott The Hoppie')

		INSERT INTO tblArtistAliases
			VALUES('435f1441-0f43-479d-92db-a506449a686b',N'Mott The Hopple')

-------------------
	INSERT INTO tblArtist 
	   VALUES ('a9044915-8be3-4c7e-b11f-9e2d2ea0a91e','Megadeth','US')

		INSERT INTO tblArtistAliases
			VALUES('a9044915-8be3-4c7e-b11f-9e2d2ea0a91e',N'Megadeath')

-------------------
	INSERT INTO tblArtist 
	   VALUES ('b625448e-bf4a-41c3-a421-72ad46cdb831','John Coltrane','US')
	
		INSERT INTO tblArtistAliases
			VALUES('b625448e-bf4a-41c3-a421-72ad46cdb831',N'John Coltraine')

		INSERT INTO tblArtistAliases
			VALUES('b625448e-bf4a-41c3-a421-72ad46cdb831',N'John William Coltrane')

-------------------
	INSERT INTO tblArtist 
	   VALUES ('d700b3f5-45af-4d02-95ed-57d301bda93e','Mogwai','GB')

		INSERT INTO tblArtistAliases
			VALUES('d700b3f5-45af-4d02-95ed-57d301bda93e',N'Mogwa')

-------------------
	INSERT INTO tblArtist 
	   VALUES ('144ef525-85e9-40c3-8335-02c32d0861f3','John Mayer','US')

-------------------
	
	INSERT INTO tblArtist 
	   VALUES ('18fa2fd5-3ef2-4496-ba9f-6dae655b2a4f','Johnny Cash','US')
	

		INSERT INTO tblArtistAliases
			VALUES('18fa2fd5-3ef2-4496-ba9f-6dae655b2a4f',N'Johhny Cash')

		INSERT INTO tblArtistAliases
			VALUES('18fa2fd5-3ef2-4496-ba9f-6dae655b2a4f',N'Jonny Cash')

-------------------
	INSERT INTO tblArtist 
	   VALUES ('6456a893-c1e9-4e3d-86f7-0008b0a3ac8a','Jack Johnson','US')

		INSERT INTO tblArtistAliases
			VALUES('6456a893-c1e9-4e3d-86f7-0008b0a3ac8a',N'Jack Hody Johnson')

-------------------
	INSERT INTO tblArtist 
	   VALUES ('f1571db1-c672-4a54-a2cf-aaa329f26f0b','John Frusciante','US')
		
		INSERT INTO tblArtistAliases
			VALUES('f1571db1-c672-4a54-a2cf-aaa329f26f0b',N'John Anthony Frusciante')
-------------------
				
	INSERT INTO tblArtist 
	   VALUES ('b83bc61f-8451-4a5d-8b8e-7e9ed295e822','Elton John','GB')
	
		INSERT INTO tblArtistAliases
			VALUES('b83bc61f-8451-4a5d-8b8e-7e9ed295e822',N'E. John')

		INSERT INTO tblArtistAliases
			VALUES('b83bc61f-8451-4a5d-8b8e-7e9ed295e822',N' Elthon John')

		INSERT INTO tblArtistAliases
			VALUES('b83bc61f-8451-4a5d-8b8e-7e9ed295e822',N'Elton Jphn')

		INSERT INTO tblArtistAliases
			VALUES('b83bc61f-8451-4a5d-8b8e-7e9ed295e822',N'John Elton')

		INSERT INTO tblArtistAliases
			VALUES('b83bc61f-8451-4a5d-8b8e-7e9ed295e822',N'Reginald Kenneth Dwight')

-------------------

	INSERT INTO tblArtist 
	   VALUES ('24f8d8a5-269b-475c-a1cb-792990b0b2ee','Rancid','US')
	INSERT INTO tblArtistAliases
			VALUES('24f8d8a5-269b-475c-a1cb-792990b0b2ee',N'ランシド')

-------------------


	INSERT INTO tblArtist 
	   VALUES ('29f3e1bf-aec1-4d0a-9ef3-0cb95e8a3699','Transplants','US')

		INSERT INTO tblArtistAliases
			VALUES('29f3e1bf-aec1-4d0a-9ef3-0cb95e8a3699',N'The Transplants')

-------------------

	INSERT INTO tblArtist 
	   VALUES ('931e1d1f-6b2f-4ff8-9f70-aa537210cd46','Operation Ivy','US')
	
		INSERT INTO tblArtistAliases
			VALUES('931e1d1f-6b2f-4ff8-9f70-aa537210cd46',N'Op Ivy')

	COMMIT TRANSACTION

END TRY

BEGIN CATCH

	-- In case of errors while inserting the values.
	IF @@trancount > 0 ROLLBACK TRANSACTION
	PRINT 'There was a problem while inserting values.';
	THROW; 	 

END CATCH

GO



-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------














